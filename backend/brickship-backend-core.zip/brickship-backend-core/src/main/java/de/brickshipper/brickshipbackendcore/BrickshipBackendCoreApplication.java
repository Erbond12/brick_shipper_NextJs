package de.brickshipper.brickshipbackendcore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrickshipBackendCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrickshipBackendCoreApplication.class, args);
	}

}
