package de.brickshipper.brickshipbackendcore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrickshipBackendCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
